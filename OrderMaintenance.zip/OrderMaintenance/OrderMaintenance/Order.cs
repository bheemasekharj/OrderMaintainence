﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderMaintenance
{
    public class Order
    {
        public string OrderID { get; set; }
        public string OrderData { get; set; }
        public DateTime OrderDate { get; set; }
        public string BuyerName { get; set; }
        public string ShipTo { get; set; }
    }
}
