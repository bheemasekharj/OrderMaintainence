﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderMaintenance
{
    public class DBHelper
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["OrderDetails"].ConnectionString;
        static MySqlConnection con;

        /// <summary>
        /// Open the Connection
        /// </summary>
        private static void OpenConection()
        {
            con = new MySqlConnection(connectionString);
            con.Open();
        }

        /// <summary>
        /// Close the Connection
        /// </summary>
        private static void CloseConnection()
        {
            con.Close();
        }

        /// <summary>
        /// Execute the Commands
        /// </summary>
        /// <param name="query"></param>
        public static int ExecuteNonQueries(string query)
        {
            int result = 0;
            try
            {
                OpenConection();
                using (MySqlCommand cmd = new MySqlCommand(query, con))
                {
                    result = cmd.ExecuteNonQuery();
                };
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }
            finally
            {
                CloseConnection();
            }
        }
        /// <summary>
        /// Execute the Query And returns the Datatable
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public static DataTable ExecuteSelect(string query)
        {
            try
            {
                DataTable dataTable;
                using (MySqlDataAdapter adr = new MySqlDataAdapter(query, connectionString))
                {
                    adr.SelectCommand.CommandType = CommandType.Text;
                    dataTable = new DataTable();
                    adr.Fill(dataTable);
                    adr.Dispose();
                }
                return dataTable;
            }
            catch (Exception ex)
            {                
                return null;
            }
        }
    }
}
