﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderMaintenance
{
    public static class Queries
    {
        /// <summary>
        /// Insert into customer Table
        /// </summary>
        /// <param name="addCustomerModel"></param>
        /// <param name="customer"></param>
        /// <returns></returns>
        public static string InsertToOrders(Order order)
        {
            return "INSERT INTO OrderTable " +
                    "( OrderID, OrderData,OrderDate, BuyerName, ShipTo)" +
                    " VALUES ('" + order.OrderID + "', '" + order.OrderData + "', '" + order.OrderDate.ToString("yyyy-MM-dd h:mm:ss") + "'," +
                    "'" + order.BuyerName + "', '" + order.ShipTo + "');";

        }

        internal static string SelectOrderID()
        {
            return "SELECT distinct orderID from OrderTable;";
        }
    }
}
