﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OrderMaintenance
{
    public partial class OrderEntry : Form
    {
        public OrderEntry()
        {
            InitializeComponent();
            GetOrderId();
        }

        private void GetOrderId()
        {
            txtOrderId.Text = DataBaseLayer.GetNextOrderID().ToString();
        }

        private void btnCreateOrder_Click(object sender, EventArgs e)
        {
            Order orderdata = new Order()
            {
                OrderID = txtOrderId.Text,
                OrderData = txtOrderData.Text,
                OrderDate = dateTimePickerOrderDate.Value,
                BuyerName = txtBuyerName.Text,
                ShipTo = txtShipTo.Text
            };
            if (!ExportToPDF(orderdata))
                return;
            DataBaseLayer.ExecuteNonQuery(orderdata);
            MessageBox.Show("Generated Pdf successfully");
            ClearAll();
        }

        private void ClearAll()
        {
            txtOrderData.Text = string.Empty;
            txtBuyerName.Text = string.Empty;
            txtShipTo.Text = string.Empty;
            dateTimePickerOrderDate.Value = DateTime.Now;
            GetOrderId();
        }

        // Export the record in to pdf
        private bool ExportToPDF(Order orderdata)
        {
            try
            {
                var path = System.IO.Path.GetDirectoryName(
                           System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
                path = path.Substring(6);                

                Document pdfdoc = new Document();
                PdfWriter.GetInstance(pdfdoc, new FileStream(path + "\\" + "Order_" + orderdata.OrderID + ".pdf", FileMode.Create));
                pdfdoc.Open();

                var spacer = new Paragraph("")
                {
                    SpacingAfter = 10f,
                    SpacingBefore = 10f
                };
                pdfdoc.Add(spacer);
                var ordertbl = new PdfPTable(new[] { .7f, 2f })
                {
                    HorizontalAlignment = Left,
                    WidthPercentage = 75,
                    DefaultCell = { MinimumHeight = 22f }
                };
                ordertbl.AddCell("OrderID");
                ordertbl.AddCell(orderdata.OrderID);
                ordertbl.AddCell("OrderData");
                ordertbl.AddCell(orderdata.OrderData);
                ordertbl.AddCell("OrderDate");
                ordertbl.AddCell(orderdata.OrderDate.ToString());
                ordertbl.AddCell("BuyerName");
                ordertbl.AddCell(orderdata.BuyerName);
                ordertbl.AddCell("ShipTo");
                ordertbl.AddCell(orderdata.ShipTo);
                pdfdoc.Add(ordertbl);
                pdfdoc.Close();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
           
            
        }
    }
}
